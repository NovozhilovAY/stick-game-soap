@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.example.org/")
package org.example.client.generated;
